/**
 * Euterpe - AI音乐生成系统
 * 前端REST API交互脚本
 */

// API基础URL
const API_BASE_URL = 'http://localhost:8000';

// 存储生成历史
let generationHistory = [];

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    // 绑定发送消息按钮
    const sendButton = document.getElementById('send-message');
    sendButton.addEventListener('click', sendMessage);

    // 绑定输入框的回车事件
    const input = document.getElementById('chatbotInput');
    input.addEventListener('keypress', (event) => {
        if (event.key === 'Enter') {
            sendMessage();
        }
    });

    // 绑定主题切换按钮
    const themeToggle = document.getElementById('theme-toggle');
    themeToggle.addEventListener('click', toggleDarkMode);

    // 从localStorage读取主题设置
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }

    // 绑定模型状态按钮
    const statusButton = document.getElementById('model-status');
    statusButton.addEventListener('click', checkModelStatus);

    // 绑定模型重载按钮
    const reloadButton = document.getElementById('reload-model');
    reloadButton.addEventListener('click', reloadModel);

    // 从localStorage加载历史记录
    loadGenerationHistory();

    // 显示欢迎消息
    setTimeout(() => {
        addChatMessage('欢迎使用Euterpe AI音乐生成系统！请描述您想要的音乐风格、情感或场景，我将为您生成音乐。', 'assistant');
    }, 500);
});

// 发送消息到后端
async function sendMessage() {
    const input = document.getElementById('chatbotInput');
    const message = input.value.trim();
    
    if (!message) return;
    
    try {
        // 显示用户消息
        addChatMessage(message, 'user');
        
        // 显示生成中消息
        const loadingId = showLoading('正在生成音乐，请稍候...');
        
        // 生成唯一用户ID
        const userId = getUserId();
        
        // 发送消息到后端
        const response = await fetch(`${API_BASE_URL}/generate`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: userId,
                    message: message
                })
            });
        
              if (!response.ok) {
            throw new Error(`网络响应错误: ${response.status} ${response.statusText}`);
            }
            
            const data = await response.json();
        console.log('服务器响应:', data);
        
        // 移除加载提示
        removeLoading(loadingId);
        
        // 处理不同类型的响应
        if (data.type === 'music') {
            // 显示生成消息
            addChatMessage(data.message, 'assistant');
            
            // 添加音频播放器
            let audioUrl;
            if (data.audio_path.startsWith('http')) {
                // 如果已经是完整URL则直接使用
                audioUrl = data.audio_path;
            } else {
                // 否则拼接基础URL
                audioUrl = `${API_BASE_URL}/${data.audio_path}`;
            }
            
            // 记录调试信息
            console.log('音频URL:', audioUrl);
            
            // 添加音频播放器
            addAudioPlayer(audioUrl, message);
            
            // 添加到历史记录
            addToHistory(message, audioUrl);
        } else {
            addChatMessage(data.message, 'assistant');
        }
        
        // 清空输入框
        input.value = '';
        
    } catch (error) {
        console.error('错误:', error);
        addChatMessage(`错误: ${error.message}`, 'system');
        
        // 移除所有加载提示
        removeAllLoadingMessages();
    }
}

// 添加文本消息到聊天窗口
function addChatMessage(message, sender) {
    const chatMessages = document.getElementById('chatbotMessages');
    const messageElement = document.createElement('div');
    messageElement.className = `message ${sender.toLowerCase()}`;
    
    // 设置消息内容
    if (sender.toLowerCase() === 'user') {
        messageElement.textContent = message;
    } else if (sender.toLowerCase() === 'assistant') {
        messageElement.textContent = message;
    } else {
        messageElement.textContent = message;
    }
    
    // 添加到聊天窗口
    chatMessages.appendChild(messageElement);
    
    // 滚动到底部
    scrollToBottom(chatMessages);
}

// 添加音频播放器
function addAudioPlayer(audioUrl, prompt) {
    const chatMessages = document.getElementById('chatbotMessages');
    const audioContainer = document.createElement('div');
    audioContainer.className = 'audio-message';
    
    // 创建音频元素
    const audio = document.createElement('audio');
    audio.controls = true;
    audio.src = audioUrl;
    
    // 添加到容器
    audioContainer.appendChild(audio);
    chatMessages.appendChild(audioContainer);
    
    // 滚动到底部
    scrollToBottom(chatMessages);
}

// 显示加载提示
function showLoading(message) {
    const loadingId = 'loading-' + Date.now();
    const chatMessages = document.getElementById('chatbotMessages');
    const loadingElement = document.createElement('div');
    loadingElement.className = 'message system';
    loadingElement.id = loadingId;
    loadingElement.innerHTML = `<div class="spinner-border spinner-border-sm text-primary me-2" role="status">
                                <span class="visually-hidden">加载中...</span>
                              </div> ${message}`;
    
    chatMessages.appendChild(loadingElement);
    scrollToBottom(chatMessages);
    
    return loadingId;
}

// 移除加载提示
function removeLoading(loadingId) {
    const loadingElement = document.getElementById(loadingId);
    if (loadingElement) {
        loadingElement.remove();
    }
}

// 移除所有加载提示
function removeAllLoadingMessages() {
    document.querySelectorAll('.message.system').forEach(el => {
        if (el.textContent.includes('正在生成')) {
            el.remove();
        }
    });
}

// 滚动到底部
function scrollToBottom(element) {
    element.scrollTop = element.scrollHeight;
}

// 获取/生成用户ID
function getUserId() {
    let userId = localStorage.getItem('userId');
    if (!userId) {
        userId = 'user-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('userId', userId);
    }
    return userId;
}

// 切换深色模式
function toggleDarkMode() {
    const body = document.body;
    const themeToggle = document.getElementById('theme-toggle');
    
    body.classList.toggle('dark-mode');
    
    if (body.classList.contains('dark-mode')) {
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        localStorage.setItem('darkMode', 'true');
    } else {
        themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        localStorage.setItem('darkMode', 'false');
    }
}

// 检查模型状态
async function checkModelStatus() {
    try {
        // 显示模态框
        const statusModal = new bootstrap.Modal(document.getElementById('statusModal'));
        statusModal.show();
        
        // 修改内容为加载中
        const statusContent = document.getElementById('model-status-content');
        statusContent.innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">加载中...</span>
                </div>
                <p class="mt-2">正在检查模型状态...</p>
            </div>
        `;
        
        // 调用API
        const response = await fetch(`${API_BASE_URL}/model/status`);
        
        if (!response.ok) {
            throw new Error(`网络响应错误: ${response.status}`);
        }
        
        const data = await response.json();
        
        // 更新状态内容
        let statusHtml = '';
        if (data.status === 'loaded') {
            statusHtml = `
                <div class="alert alert-success">
                    <i class="fas fa-check-circle me-2"></i> 模型已加载
                </div>
                <table class="table">
                    <tr>
                        <td>设备</td>
                        <td>${data.device}</td>
                    </tr>
                    <tr>
                        <td>参数数量</td>
                        <td>${data.model_info.total_parameters_millions.toFixed(2)} M</td>
                    </tr>
                    <tr>
                        <td>模型大小</td>
                        <td>${data.model_info.model_size_gb.toFixed(2)} GB</td>
                    </tr>
                </table>
            `;
        } else {
            statusHtml = `
                <div class="alert alert-warning">
                    <i class="fas fa-exclamation-triangle me-2"></i> 模型未加载
                </div>
                <p>请点击"重新加载模型"按钮加载模型。</p>
            `;
        }
        
        statusContent.innerHTML = statusHtml;
        
    } catch (error) {
        console.error('检查模型状态时出错:', error);
        
        // 显示错误
        const statusContent = document.getElementById('model-status-content');
        statusContent.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i> 检查模型状态时出错
            </div>
            <p>${error.message}</p>
        `;
    }
}

// 重新加载模型
async function reloadModel() {
    try {
        // 修改重载按钮状态
        const reloadButton = document.getElementById('reload-model');
        reloadButton.disabled = true;
        reloadButton.innerHTML = `
            <span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
            加载中...
        `;
        
        // 修改状态内容
        const statusContent = document.getElementById('model-status-content');
        statusContent.innerHTML = `
            <div class="text-center">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">加载中...</span>
                </div>
                <p class="mt-2">正在重新加载模型，这可能需要几分钟时间...</p>
            </div>
        `;
        
        // 调用API
        const response = await fetch(`${API_BASE_URL}/model/reload`, {
            method: 'POST'
        });
        
        if (!response.ok) {
            throw new Error(`网络响应错误: ${response.status}`);
        }
        
        const data = await response.json();
        
        // 更新状态
        statusContent.innerHTML = `
            <div class="alert alert-success">
                <i class="fas fa-check-circle me-2"></i> ${data.message}
            </div>
        `;
        
        // 恢复按钮状态
        reloadButton.disabled = false;
        reloadButton.innerHTML = '重新加载模型';
        
    } catch (error) {
        console.error('重新加载模型时出错:', error);
        
        // 显示错误
        const statusContent = document.getElementById('model-status-content');
        statusContent.innerHTML = `
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle me-2"></i> 重新加载模型时出错
            </div>
            <p>${error.message}</p>
        `;
        
        // 恢复按钮状态
        const reloadButton = document.getElementById('reload-model');
        reloadButton.disabled = false;
        reloadButton.innerHTML = '重新加载模型';
    }
}

// 添加生成记录到历史
function addToHistory(prompt, audioUrl) {
    // 创建新的历史记录
    const historyItem = {
        id: Date.now(),
        prompt: prompt,
        audioUrl: audioUrl,
        timestamp: new Date().toISOString()
    };
    
    // 添加到历史列表
    generationHistory.unshift(historyItem); // 添加到开头
    
    // 限制历史记录数量
    if (generationHistory.length > 20) {
        generationHistory.pop(); // 移除最旧的记录
    }
    
    // 保存到本地存储
    localStorage.setItem('generationHistory', JSON.stringify(generationHistory));
    
    // 更新历史UI
    updateHistoryUI();
}

// 更新历史记录UI
function updateHistoryUI() {
    const historyContainer = document.getElementById('history-container');
    
    if (generationHistory.length === 0) {
        historyContainer.innerHTML = '<p class="text-muted text-center">暂无生成历史</p>';
        return;
    }
    
    let historyHTML = '';
    
    generationHistory.forEach(item => {
        const date = new Date(item.timestamp);
        const timeString = date.toLocaleString('zh-CN', {
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
        
        historyHTML += `
            <div class="history-item" data-audio="${item.audioUrl}" data-prompt="${item.prompt}" onclick="replayAudio(this)">
                <span class="time">${timeString}</span>
                <span class="prompt">${item.prompt}</span>
                <button class="btn btn-sm btn-outline-primary ms-2">
                    <i class="fas fa-play"></i>
                </button>
            </div>
        `;
    });
    
    historyContainer.innerHTML = historyHTML;
}

// 从localStorage加载历史记录
function loadGenerationHistory() {
    const savedHistory = localStorage.getItem('generationHistory');
    if (savedHistory) {
        try {
            generationHistory = JSON.parse(savedHistory);
            updateHistoryUI();
        } catch (e) {
            console.error('解析历史记录时出错:', e);
            localStorage.removeItem('generationHistory');
            generationHistory = [];
        }
    }
}

// 重播历史音频
function replayAudio(element) {
    const audioUrl = element.getAttribute('data-audio');
    const prompt = element.getAttribute('data-prompt');
    
    console.log('重播音频URL:', audioUrl);
    
    addChatMessage(`重播: ${prompt}`, 'system');
    addAudioPlayer(audioUrl, prompt);
}

// 将replayAudio函数暴露给全局作用域，以便内联onclick处理程序可以访问它
window.replayAudio = replayAudio;
