function toggleMenu() {
  const menuContent = document.getElementById('menuContent');
  menuContent.style.display = menuContent.style.display === 'block' ? 'none' : 'block';
}

function startAnalysis() {
  const fileInput = document.getElementById('fileInput').files[0];
  if (fileInput) {
    document.getElementById('analyzeBox').innerText = `Analyzing: ${fileInput.name}`;
    document.getElementById('recentSongsTitle').innerText = fileInput.name;
  } else {
    alert('Please select a file first.');
  }
}

function toggleChatbot() {
  const chatbotContainer = document.getElementById('chatbotContainer');
  const chatbotButton = document.querySelector('.chatbot-button');
  if (chatbotContainer.style.display === 'block') {
    chatbotContainer.style.display = 'none';
    chatbotButton.classList.remove('expanded');
  } else {
    chatbotContainer.style.display = 'block';
    chatbotButton.classList.add('expanded');
    document.getElementById('chatbotInput').focus();
  }
}

function addChatMessage(message, who) {
  const chatbotMessages = document.getElementById('chatbotMessages');
  const messageElement = document.createElement('div');
  messageElement.textContent = `${who}: ${message}`;
  chatbotMessages.appendChild(messageElement);
  chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
}

function sendMessage() {
  const input = document.getElementById('chatbotInput');
  const message = input.value.trim();
  if (message) {
    const chatbotMessages = document.getElementById('chatbotMessages');
    const messageElement = document.createElement('div');
    messageElement.textContent = `You: ${message}`;
    chatbotMessages.appendChild(messageElement);
    input.value = '';

    // Simulate a response
    setTimeout(() => {
      const responseElement = document.createElement('div');
      responseElement.textContent = `Chatbot: This is a response to "${message}"`;
      chatbotMessages.appendChild(responseElement);
      chatbotMessages.scrollTop = chatbotMessages.scrollHeight;
    }, 1000);
  }
}

function saveCategoryName(event) {
  const span = event.target;
  span.contentEditable = false;
  // Additional logic to save the new category name could go here
}

function saveSubCategoryName(event) {
  const div = event.target;
  div.contentEditable = false;
  // Additional logic to save the new sub-category name could go here
}

function viewSongs(type) {
  const title = type === 'recently' ? 'Recently Played Songs' : 'Chosen Songs';
  document.getElementById('recentSongsTitle').innerText = title;
}

function addSubCategory() {
  const activeElement = document.querySelector('.context-menu.active');
  if (activeElement) {
    const newSubCategory = document.createElement('div');
    newSubCategory.className = 'menu-item';
    newSubCategory.contentEditable = true;
    newSubCategory.onblur = function(event) {
            saveSubCategoryName(event);
        };
        newSubCategory.innerText = 'New Sub-Category';
        e = document.querySelector('.sub-menu');
        console.log(e);
        e.appendChild(newSubCategory);
        e.style.display = 'block';
    }
}

function showContextMenu(event, target) {
    event.preventDefault();
    const contextMenu = document.getElementById('contextMenu');
    contextMenu.style.left = `${event.pageX}px`;
    contextMenu.style.top = `${event.pageY}px`;
    contextMenu.style.display = 'block';
    contextMenu.classList.add('active');
    document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
    target.classList.add('active');
}

function showContextMenu2(event, target) {
    event.preventDefault();
    const contextMenu = document.getElementById('contextMenu2');
    contextMenu.style.left = `${event.pageX}px`;
    contextMenu.style.top = `${event.pageY}px`;
    contextMenu.style.display = 'block';
    contextMenu.classList.add('active');
    document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
    target.classList.add('active');
}

function changeName() {
    const activeItem = document.querySelector('.context-menu.active');
    if (activeItem) {
        const span = activeItem.querySelector('.editable');
        if (span) {
            const newName = prompt('Enter new name:', span.innerText);
            if (newName) {
                span.innerText = newName;
            }
        }
    }
    document.getElementById('contextMenu').style.display = 'none';
}

function editCategoryName(event) {
    document.getElementById('contextMenu').style.display = 'none';
    //const span = event.target;
    const span = document.getElementById('categories_item')
    span.contentEditable = true;
    span.focus();
    span.onblur = saveCategoryName;
}

function editSubCategoryName(event) {
    const span = event.target;
    span.contentEditable = true;
    span.focus();
    span.onblur = saveSubCategoryName;
}

window.addEventListener("load", (event) => {

    // build out the sub-menu of categories:
    category_list = ["Happy", "Sad"];
    parent_div = document.getElementById('categories');
    // class="menu-item" oncontextmenu="showContextMenu(event, this)">
    // <span class="editable" onclick="editSubCategoryName(event)">Category 1</span>
    for (i=0; i<category_list.length; i++) {
        new_category = document.createElement('div');
        new_category.innerHTML = category_list[i];
        parent_div.appendChild(new_category);
    }

    document.addEventListener('click', function(event) {
        const contextMenu = document.getElementById('contextMenu');
        if (!contextMenu.contains(event.target)) {
            contextMenu.style.display = 'none';
            contextMenu.classList.remove('active');
        }
    });
    
    document.addEventListener('contextmenu', function(event) {
        event.preventDefault();
    });
    

    const cookieConsentContainer = document.getElementById('cookieConsentContainer');
    const acceptCookies = document.getElementById('acceptCookies');
    const declineCookies = document.getElementById('declineCookies');

    const setCookie = (name, value, days) => {
        const d = new Date();
        d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
        const expires = "expires=" + d.toUTCString();
        document.cookie = name + "=" + value + ";" + expires + ";path=/";
    }

    const getCookie = (name) => {
        const nameEQ = name + "=";
        const ca = document.cookie.split(';');
        for(let i = 0; i < ca.length; i++) {
            let c = ca[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    const checkCookieConsent = () => {
        const cookieConsent = getCookie("cookieConsent");
        if (!cookieConsent) {
            cookieConsentContainer.style.display = "block";
        }
    }

    acceptCookies.addEventListener('click', () => {
        setCookie("cookieConsent", "accepted", 365);
        cookieConsentContainer.style.display = "none";
    });

    declineCookies.addEventListener('click', () => {
        setCookie("cookieConsent", "declined", 365);
        cookieConsentContainer.style.display = "none";
    });

    checkCookieConsent();

    const trackButton = document.getElementById('trackButton');

    trackButton.addEventListener('click', () => {
        trackAction('buttonClick');
    });

    // Example of setting and reading a cookie
    function trackAction(action) {
        let actions = getCookie('userActions');
        actions = actions ? JSON.parse(actions) : [];
        actions.push({ action, timestamp: new Date().toISOString() });
        setCookie('userActions', JSON.stringify(actions), 7);
    }

    // Example: Reading the tracked actions
    function readActions() {
        const actions = getCookie('userActions');
        return actions ? JSON.parse(actions) : [];
    }

    // Example: Logging the actions
    console.log(readActions());
});

// Set a cookie
function setCookie(name, value, days) {
    const d = new Date();
    d.setTime(d.getTime() + (days * 24 * 60 * 60 * 1000));
    const expires = "expires=" + d.toUTCString();
    document.cookie = name + "=" + value + ";" + expires + ";path=/";
}

// Get a cookie
function getCookie(name) {
    const nameEQ = name + "=";
    const ca = document.cookie.split(';');
    for (let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) === ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}

// Delete a cookie
function deleteCookie(name) {
    document.cookie = name + '=; Max-Age=-99999999;';
};
